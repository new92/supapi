from supapi.__init__ import __version__

def vers():
    assert __version__ == '0.1.5'